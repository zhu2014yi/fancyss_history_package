{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2022-06-04 23:25",
    "md5": "51e14919bca02b38cc31fe3fff03f343",
    "count": "5561"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2022-06-05 00:05",
    "md5": "f12a5a7fb6c9c37d52dbbea0666812ba",
    "count": "6182",
    "count_ip": "13240665434"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2022-06-05 00:04",
    "md5": "750b84a9ca8da7162cb53375acbbebac",
    "count": "66414"
  },
  "apple_china": {
    "name": "apple_china.txt",
    "date": "2022-06-01 17:54",
    "md5": "f9de2c1c862bc12d5d96e350c4fc8991",
    "count": "124"
  },
  "google_china": {
    "name": "google_china.txt",
    "date": "2022-06-05 00:04",
    "md5": "24986fc4b1d9216b5e24b7e54100df3d",
    "count": "71"
  },
  "cdn_test": {
    "name": "cdn_test.txt",
    "date": "2022-06-01 17:54",
    "md5": "6238d54f2bb2537088ac8e0f645a4386",
    "count": "70"
  }
}
